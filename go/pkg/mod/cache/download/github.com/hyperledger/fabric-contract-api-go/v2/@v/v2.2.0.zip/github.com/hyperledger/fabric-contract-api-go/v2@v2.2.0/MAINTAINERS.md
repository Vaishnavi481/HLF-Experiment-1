# Maintainers

| Name         | GitHub                                                | Chat            | email                      |
| ------------ | ----------------------------------------------------- | --------------- | -------------------------- |
| Dave Enyeart | [denyeart](https://github.com/denyeart)               | denyeart        | <enyeart@us.ibm.com>       |
| Mark Lewis   | [bestbeforetoday](https://github.com/bestbeforetoday) | bestbeforetoday | <Mark.S.Lewis@outlook.com> |

# Retired Maintainers

| Name          | GitHub                                | Chat     | email                 |
| ------------- | ------------------------------------- | -------- | --------------------- |
| Matthew White | [mbwhite](https://github.com/mbwhite) |          | <whitemat@uk.ibm.com> |
| James Taylor  | [jt-nti](https://github.com/jt-nti)   | jtonline | <jamest@uk.ibm.com>   |

Also: Please see the [Release Manager section](https://github.com/hyperledger/fabric/blob/main/MAINTAINERS.md)
