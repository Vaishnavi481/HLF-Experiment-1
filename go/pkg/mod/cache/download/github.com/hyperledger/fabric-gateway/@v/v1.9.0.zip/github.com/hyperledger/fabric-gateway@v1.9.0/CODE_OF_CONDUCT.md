# Code of conduct

This project follows the [LF Decentralized Trust code of conduct](https://lf-decentralized-trust.github.io/governance/governing-documents/code-of-conduct). Please review these guidelines before participating.
