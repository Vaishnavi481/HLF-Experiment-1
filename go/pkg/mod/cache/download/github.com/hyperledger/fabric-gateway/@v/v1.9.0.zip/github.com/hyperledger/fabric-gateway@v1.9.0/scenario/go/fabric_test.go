// Copyright IBM Corp. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

package scenario

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"time"

	"golang.org/x/sync/errgroup"
)

const (
	fixturesDir       = "../fixtures"
	dockerComposeFile = "docker-compose-tls.yaml"
	dockerComposeDir  = fixturesDir + "/docker-compose"
)

type orgConfig struct {
	cli   string
	peers []string
}

type ordererConfig struct {
	address string
	port    string
}

var orgs = []orgConfig{
	{
		cli:   "org1_cli",
		peers: []string{"peer0.org1.example.com:7051", "peer1.org1.example.com:9051"},
	},
	{
		cli:   "org2_cli",
		peers: []string{"peer0.org2.example.com:8051", "peer1.org2.example.com:10051"},
	},
	{
		cli:   "org3_cli",
		peers: []string{"peer0.org3.example.com:11051"},
	},
}

var orderers = []ordererConfig{
	{address: "orderer1.example.com", port: "7053"},
	{address: "orderer2.example.com", port: "8053"},
	{address: "orderer3.example.com", port: "9053"},
}

type peerConnectionInfo struct {
	host               string
	port               uint16
	serverNameOverride string
	tlsRootCertPath    string
	running            bool
	healthzPort        uint16
}

var peerConnectionInfos = map[string]*peerConnectionInfo{
	"peer0.org1.example.com": {
		host:               "localhost",
		port:               7051,
		serverNameOverride: "peer0.org1.example.com",
		tlsRootCertPath:    fixturesDir + "/crypto-material/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt",
		running:            true,
		healthzPort:        7443,
	},
	"peer1.org1.example.com": {
		host:               "localhost",
		port:               9051,
		serverNameOverride: "peer1.org1.example.com",
		tlsRootCertPath:    fixturesDir + "/crypto-material/crypto-config/peerOrganizations/org1.example.com/peers/peer1.org1.example.com/tls/ca.crt",
		running:            true,
		healthzPort:        9443,
	},
	"peer0.org2.example.com": {
		host:               "localhost",
		port:               8051,
		serverNameOverride: "peer0.org2.example.com",
		tlsRootCertPath:    fixturesDir + "/crypto-material/crypto-config/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt",
		running:            true,
		healthzPort:        8443,
	},
	"peer1.org2.example.com": {
		host:               "localhost",
		port:               10051,
		serverNameOverride: "peer1.org2.example.com",
		tlsRootCertPath:    fixturesDir + "/crypto-material/crypto-config/peerOrganizations/org2.example.com/peers/peer1.org2.example.com/tls/ca.crt",
		running:            true,
		healthzPort:        10443,
	},
	"peer0.org3.example.com": {
		host:               "localhost",
		port:               11051,
		serverNameOverride: "peer0.org3.example.com",
		tlsRootCertPath:    fixturesDir + "/crypto-material/crypto-config/peerOrganizations/org3.example.com/peers/peer0.org3.example.com/tls/ca.crt",
		running:            true,
		healthzPort:        11443,
	},
}

var _mspToOrgMap map[string]string

func GetOrgForMSP(mspID string) string {
	if nil == _mspToOrgMap {
		_mspToOrgMap = make(map[string]string)
		_mspToOrgMap["Org1MSP"] = "org1.example.com"
		_mspToOrgMap["Org2MSP"] = "org2.example.com"
		_mspToOrgMap["Org3MSP"] = "org3.example.com"
	}

	return _mspToOrgMap[mspID]
}

var (
	fabricRunning     = false
	channelsJoined    = false
	runningChaincodes = make(ChaincodeSet)
)

type ChaincodeSet map[string]string

func (set ChaincodeSet) policy(chaincodeName string, version string, channelName string) (policy string, exists bool) {
	key := chaincodeKey(chaincodeName, version, channelName)
	policy, exists = set[key]
	return
}

func chaincodeKey(chaincodeName string, version string, channelName string) string {
	return chaincodeName + version + channelName
}

func (set ChaincodeSet) add(chaincodeName string, version string, channelName string, signaturePolicy string) {
	key := chaincodeKey(chaincodeName, version, channelName)
	set[key] = signaturePolicy
}

func startFabric() error {
	if !fabricRunning {
		fmt.Println("startFabric")
		err := createCryptoMaterial()
		if err != nil {
			return err
		}
		cmd := exec.Command("docker", "compose", "-f", dockerComposeFile, "-p", "node", "up", "-d")
		cmd.Dir = dockerComposeDir
		out, err := cmd.CombinedOutput()
		if out != nil {
			fmt.Println(string(out))
		}
		if err != nil {
			return err
		}
		fabricRunning = true
		for peer := range peerConnectionInfos {
			waitForHealthzOK(peer)
		}
	} else {
		fmt.Println("Fabric already running")
	}

	return nil
}

func stopFabric() error {
	if fabricRunning {
		fmt.Println("stopFabric")
		cmd := exec.Command("docker", "compose", "-f", dockerComposeFile, "-p", "node", "down")
		cmd.Dir = dockerComposeDir
		out, err := cmd.CombinedOutput()
		if out != nil {
			fmt.Println(string(out))
		}
		if err != nil {
			return err
		}
		fabricRunning = false
	}
	return nil
}

func createCryptoMaterial() error {
	fmt.Println("createCryptoMaterial")
	cmd := exec.Command("./generate.sh")
	cmd.Dir = fixturesDir
	out, err := cmd.CombinedOutput()
	if out != nil {
		fmt.Println(string(out))
	}
	if err != nil {
		return err
	}
	return nil
}

func generateHSMUser(hsmUserid string) error {
	fmt.Println("generateHSMUser")
	cmd := exec.Command("./generate-hsm-user.sh", hsmUserid)
	cmd.Dir = fixturesDir
	out, err := cmd.CombinedOutput()
	if out != nil {
		fmt.Println(string(out))
	}
	if err != nil {
		return err
	}
	return nil
}

func deployChaincode(ccType, ccName, version, channelName, signaturePolicy string) error {
	fmt.Println("deployChaincode")

	sequence := "1"

	if policy, exists := runningChaincodes.policy(ccName, version, channelName); exists {
		if policy == signaturePolicy {
			// Nothing to do as already deployed with correct signature policy.
			return nil
		}

		// Already exists but different signature policy...
		// No need to re-install, just increment the sequence number and approve/commit new signature policy.
		currentSequence, err := committedSequenceNumber(ccName, channelName)
		if err != nil {
			return err
		}
		sequence = strconv.Itoa(currentSequence + 1)
	} else {
		if err := installChaincode(ccName, ccType, version); err != nil {
			return err
		}
	}

	// is there a collections_config.json file?
	var collectionConfig []string
	collectionFile := "/chaincode/" + ccType + "/" + ccName + "/collections_config.json"
	if _, err := os.Stat(fixturesDir + collectionFile); err == nil {
		collectionConfig = []string{
			"--collections-config",
			"/opt/gopath/src/github.com" + collectionFile,
		}
	}

	if err := approveChaincode(ccName, version, sequence, channelName, signaturePolicy, collectionConfig); err != nil {
		return err
	}

	if err := commitChaincode(ccName, version, sequence, channelName, signaturePolicy, collectionConfig); err != nil {
		return err
	}

	runningChaincodes.add(ccName, version, channelName, signaturePolicy)

	return nil
}

func committedSequenceNumber(chaincodeName string, channelName string) (int, error) {
	out, err := dockerCommandWithTLS(
		"exec", "org1_cli", "peer", "lifecycle", "chaincode", "querycommitted",
		"-o", "orderer1.example.com:7050", "--channelID", channelName, "--name", chaincodeName,
	)
	if err != nil {
		return 0, err
	}

	pattern := regexp.MustCompile(".*Sequence: ([0-9]+),.*")
	match := pattern.FindStringSubmatch(out)
	if len(match) != 2 {
		return 0, errors.New("cannot find installed chaincode for Org1")
	}
	i, err := strconv.Atoi(match[1])
	if err != nil {
		return 0, err
	}

	return i, nil
}

func installChaincode(name string, language string, version string) error {
	path := "/opt/gopath/src/github.com/chaincode/" + language + "/" + name
	pkg := name + ".tar.gz"

	wg := new(errgroup.Group)

	for _, org := range orgs {
		wg.Go(func() error {
			return installChaincodeToOrg(org, pkg, language, name, version, path)
		})
	}

	return wg.Wait()
}

func installChaincodeToOrg(org orgConfig, pkg string, language string, name string, version string, path string) error {
	if _, err := dockerCommand(
		"exec", org.cli, "peer", "lifecycle", "chaincode", "package", pkg,
		"--lang", language,
		"--label", chaincodeLabel(name, version),
		"--path", path,
	); err != nil {
		return err
	}

	wg := new(errgroup.Group)

	for _, peer := range org.peers {
		wg.Go(func() error {
			return installChaincodeToPeer(peer, org, pkg)
		})
	}

	return wg.Wait()
}

func installChaincodeToPeer(peer string, org orgConfig, pkg string) error {
	env := "CORE_PEER_ADDRESS=" + peer
	if _, err := dockerCommand(
		"exec", "-e", env, org.cli, "peer", "lifecycle", "chaincode", "install", pkg,
	); err != nil {
		return err
	}
	return nil
}

func chaincodeLabel(name string, version string) string {
	return name + "v" + version
}

func approveChaincode(name string, version string, sequence string, channelName string, signaturePolicy string, collectionConfig []string) error {
	wg := new(errgroup.Group)

	for _, org := range orgs {
		wg.Go(func() error {
			return approveChaincodeForOrg(org, name, version, channelName, signaturePolicy, sequence, collectionConfig)
		})
	}

	return wg.Wait()
}

func approveChaincodeForOrg(org orgConfig, name string, version string, channelName string, signaturePolicy string, sequence string, collectionConfig []string) error {
	out, err := dockerCommand(
		"exec", org.cli, "peer", "lifecycle", "chaincode", "queryinstalled",
	)
	if err != nil {
		return err
	}

	label := chaincodeLabel(name, version)
	pattern := regexp.MustCompile(".*Package ID: (.*), Label: " + label + ".*")
	match := pattern.FindStringSubmatch(out)
	if len(match) != 2 {
		return errors.New("cannot find installed chaincode for Org1")
	}
	packageID := match[1]

	approveCommand := []string{
		"exec", org.cli, "peer", "lifecycle", "chaincode", "approveformyorg",
		"--package-id", packageID,
		"--channelID", channelName,
		"--orderer", "orderer1.example.com:7050",
		"--name", name,
		"--version", version,
		"--signature-policy", signaturePolicy,
		"--sequence", sequence,
		"--waitForEvent",
	}
	approveCommand = append(approveCommand, collectionConfig...)
	if _, err = dockerCommandWithTLS(approveCommand...); err != nil {
		return err
	}
	return nil
}

func commitChaincode(name string, version string, sequence string, channelName string, signaturePolicy string, collectionConfig []string) error {
	commitCommand := []string{
		"exec", "org1_cli", "peer", "lifecycle", "chaincode", "commit",
		"--channelID", channelName,
		"--orderer", "orderer1.example.com:7050",
		"--name", name,
		"--version", version,
		"--signature-policy", signaturePolicy,
		"--sequence", sequence,
		"--waitForEvent",
		"--peerAddresses", "peer0.org1.example.com:7051",
		"--peerAddresses", "peer1.org1.example.com:9051",
		"--peerAddresses", "peer0.org2.example.com:8051",
		"--peerAddresses", "peer1.org2.example.com:10051",
		"--peerAddresses", "peer0.org3.example.com:11051",
		"--tlsRootCertFiles",
		"/etc/hyperledger/configtx/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt",
		"--tlsRootCertFiles",
		"/etc/hyperledger/configtx/crypto-config/peerOrganizations/org1.example.com/peers/peer1.org1.example.com/tls/ca.crt",
		"--tlsRootCertFiles",
		"/etc/hyperledger/configtx/crypto-config/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt",
		"--tlsRootCertFiles",
		"/etc/hyperledger/configtx/crypto-config/peerOrganizations/org2.example.com/peers/peer1.org2.example.com/tls/ca.crt",
		"--tlsRootCertFiles",
		"/etc/hyperledger/configtx/crypto-config/peerOrganizations/org3.example.com/peers/peer0.org3.example.com/tls/ca.crt",
	}
	commitCommand = append(commitCommand, collectionConfig...)
	_, err := dockerCommandWithTLS(commitCommand...)
	if err != nil {
		return err
	}

	return nil
}

func createAndJoinChannels() error {
	fmt.Println("createAndJoinChannels")

	if err := startAllPeers(); err != nil {
		return err
	}

	if channelsJoined {
		return nil
	}

	if err := joinOrderers(); err != nil {
		return err
	}

	if err := joinPeers(); err != nil {
		return err
	}

	channelsJoined = true

	for peer := range peerConnectionInfos {
		waitForHealthzOK(peer)
	}

	return nil
}

func joinOrderers() error {
	wg := new(errgroup.Group)

	for _, orderer := range orderers {
		wg.Go(func() error {
			return joinOrderer(orderer)
		})
	}

	return wg.Wait()
}

func joinOrderer(orderer ordererConfig) error {
	tlsdir := fmt.Sprintf("/etc/hyperledger/configtx/crypto-config/ordererOrganizations/example.com/orderers/%s/tls", orderer.address)
	if _, err := dockerCommand(
		"exec", "org1_cli", "osnadmin", "channel", "join",
		"--channelID", "mychannel",
		"--config-block", "/etc/hyperledger/configtx/mychannel.block",
		"-o", fmt.Sprintf("%s:%s", orderer.address, orderer.port),
		"--ca-file", "/etc/hyperledger/configtx/crypto-config/ordererOrganizations/example.com/tlsca/tlsca.example.com-cert.pem",
		"--client-cert", tlsdir+"/server.crt",
		"--client-key", tlsdir+"/server.key",
	); err != nil {
		return err
	}
	return nil
}

func joinPeers() error {
	wg := new(errgroup.Group)

	for _, org := range orgs {
		for _, peer := range org.peers {
			wg.Go(func() error {
				return joinPeer(peer, org)
			})
		}
	}
	return nil
}

func joinPeer(peer string, org orgConfig) error {
	env := "CORE_PEER_ADDRESS=" + peer
	if _, err := dockerCommandWithTLS(
		"exec", "-e", env, org.cli, "peer", "channel", "join",
		"-b", "/etc/hyperledger/configtx/mychannel.block",
	); err != nil {
		return err
	}
	return nil
}

func stopPeer(peer string) error {
	_, err := dockerCommand(
		"stop", peer,
	)
	if err != nil {
		return err
	}
	peerConnectionInfos[peer].running = false
	return nil
}

func startPeer(peer string) error {
	_, err := dockerCommand(
		"start", peer,
	)
	if err != nil {
		return err
	}
	peerConnectionInfos[peer].running = true
	waitForHealthzOK(peer)
	return nil
}

func waitForHealthzOK(peer string) {
	peerInfo := peerConnectionInfos[peer]
	healthzURL := fmt.Sprintf("http://%s:%d/healthz", peerInfo.host, peerInfo.healthzPort)

	var health *HealthStatus
	for !health.IsOK() {
		if health != nil {
			time.Sleep(500 * time.Millisecond)
		}

		if current, err := getHealth(healthzURL); err != nil {
			health = new(HealthStatus)
		} else {
			if !current.IsOK() {
				log.Printf("Bad health for peer %s: %v\n", peer, current)
			}
			health = current
		}
	}
}

func getHealth(url string) (*HealthStatus, error) {
	response, err := http.Get(url) //nolint:gosec
	if err != nil {
		return nil, err
	}

	body, err := io.ReadAll(response.Body)
	if err != nil {
		return nil, err
	}

	result := new(HealthStatus)
	if err := json.Unmarshal(body, result); err != nil {
		return nil, err
	}

	return result, nil
}

// FailedCheck represents a failed status check for a component.
type FailedCheck struct {
	Component string `json:"component"`
	Reason    string `json:"reason"`
}

// HealthStatus represents the current health status of all registered components.
type HealthStatus struct {
	Status       string        `json:"status"`
	Time         time.Time     `json:"time"`
	FailedChecks []FailedCheck `json:"failed_checks,omitempty"`
}

func (h *HealthStatus) IsOK() bool {
	return h != nil && h.Status == "OK"
}

func startAllPeers() error {
	fmt.Println("startAllPeers")
	startedPeers := false
	for peer, info := range peerConnectionInfos {
		if !info.running {
			if _, err := dockerCommand("start", peer); err != nil {
				return err
			}
			peerConnectionInfos[peer].running = true
			startedPeers = true
		}
	}

	if startedPeers {
		for peer := range peerConnectionInfos {
			waitForHealthzOK(peer)
		}
	}
	return nil
}

func dockerCommandWithTLS(args ...string) (string, error) {
	tlsOptions := []string{
		"--tls",
		//"true",
		"--cafile",
		"/etc/hyperledger/configtx/crypto-config/ordererOrganizations/example.com/tlsca/tlsca.example.com-cert.pem",
	}

	fullArgs := append(args, tlsOptions...)
	return dockerCommand(fullArgs...)
}

func dockerCommand(args ...string) (string, error) {
	fmt.Println("\033[1m", ">", "docker", strings.Join(args, " "), "\033[0m")
	cmd := exec.Command("docker", args...)
	out, err := cmd.CombinedOutput()
	if out != nil {
		fmt.Println(string(out))
	}
	if err != nil {
		return "", fmt.Errorf("%w: %s", err, string(out))
	}

	return string(out), nil
}

func haveFabricNetwork() error {
	if !fabricRunning {
		return startFabric()
	}
	return nil
}
